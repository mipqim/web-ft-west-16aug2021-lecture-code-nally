
Slides for this presentation are here:

[https://docs.google.com/presentation/d/1ExvYAIYJ5HcEKQz3kD_gyqteFFkuFAxkrsEj_qvGsds/edit?usp=sharing](https://docs.google.com/presentation/d/1ExvYAIYJ5HcEKQz3kD_gyqteFFkuFAxkrsEj_qvGsds/edit?usp=sharing)


Sources and Resources
=====================

# Some clever commands

https://github.com/engineer-man/youtube/blob/master/058/commands.sh

# How to write bash scripts

https://www.youtube.com/watch?v=F-gskSl4pwQ

# Making a set of directories, oh, for say 12 directories each with 5 subdirectories inside

mkdir -p {1..12}/{1..5}

# 20 Bash Tricks in 5 Minutes

https://www.youtube.com/watch?v=pEN4WnFNMx0

